#!/usr/bin/env python3.6 
# coding: utf8
# Credit: (Only slightly) Modified from: https://www.sigmdel.ca/michel/program/python/tide_cdn_en.html

## Script to get the times and height of low and high tides in a given day 
## at a given place.


import sys
sys.path.append(r'./env/lib/python3.5/site-packages/')
from suds.client import Client
from datetime import datetime, timedelta

TZ          = -4  # Timezone: AST, -3 for ADT

###############################################################################
# Parameters required:
#
date        = "2021-04-08" #Date as "YYYY-MM-DD"
## One or the other of stationID or stationName must be given. 
# The stationName does not have to be a perfect match to the actual name
# For example 'shediac' will match 'Shediac Bay *'. 
# Look at http://www.tides.gc.ca/eng/station/list for possible values
stationID   = "10"
stationName = "North Head" 

startTime   = "10:00:00" # HH:MM:SS format
endTime     = "23:59:59" # HH:MM:SS format
###############################################################################

# Need UTC time for start and end of the date
start_dt = datetime.strptime(date + " " + startTime, "%Y-%m-%d %H:%M:%S") - timedelta(hours=TZ)
end_dt = datetime.strptime(date + " " + endTime, "%Y-%m-%d %H:%M:%S") - timedelta(hours=TZ)

# Convert the times to strings as needed for the search
sdt = start_dt.strftime("%Y-%m-%d %H:%M:%S")
edt = end_dt.strftime("%Y-%m-%d %H:%M:%S")

client = Client("https://ws-shc.qc.dfo-mpo.gc.ca/predictions?wsdl")

# The geographic coordinates in the search correspond to earth as a whole; 
# the metadata station_id or stations_name will be used to select the area

# Using station_id metadata
#rest = client.service.search("hilo",  -90.0,  90.0, -180.0, 180.0,  0.0,  0.0,  sdt, edt, 1, 5, True,"station_id="+stationID, "asc")  

# Using station_name metadata
rest = client.service.search("hilo",  -90.0,  90.0, -180.0, 180.0,  0.0,  0.0,  sdt, edt, 1, 5, True,"station_name="+stationName, "asc")  

data = rest.data

# Recover the name in case station_id was used to select the area
# or the "official" station name if station_name was used to select the area
meta = data[0].metadata
where = meta[1].value

## Print header as per CHS web page

# English header
print("Times and Heights for High and Low Tides at "+where+", "+date)

# print data
for x in data:
    dt = datetime.strptime(x.boundaryDate.max, "%Y-%m-%d %H:%M:%S") + timedelta(hours=TZ)
    print (dt.strftime("  %H:%M "), x.value, "(m)")

#!/usr/bin/env python3.6
# coding: utf8

# This example program demonstrates
# 1. connecting to a web service,
# 2. identifying components of its WSDL,
# 3. performing a web service call.

import sys
sys.path.append(r'./env/lib/python3.5/site-packages/')
from suds.client import Client
from datetime import datetime, timedelta
if len(sys.argv) < 2 :
    print('Usage: ' +sys.argv[0]+ ' WSDL_URL')
    sys.exit(1)
clientURL = sys.argv[1]
# Connect and return the WSDL document
# Example cients:
# http://calculator-webservice.mybluemix.net/calculator?wsdl
# https://ws-shc.qc.dfo-mpo.gc.ca/predictions?wsdl
#
client = Client(clientURL)

# How many services are there?
print('Number of services: ',end='')
print(len(client.wsdl.services))
# How many ports (portTypes) are there?
print('Number of ports: ',end='')
print(len(client.wsdl.services[0].ports))
# How many methods are there?#
print('Number of methods: ',end='')
print(len(client.wsdl.services[0].ports[0].methods))
# List the methods:
methods = [method for method in client.wsdl.services[0].ports[0].methods]
print(methods)

# input parameters (if any) for each method
for method in methods:
    print(method)
    fullMethod = client.wsdl.services[0].ports[0].methods[method]
    params = client.wsdl.services[0].ports[0].methods[method].binding.input.param_defs(client.wsdl.services[0].ports[0].methods[method])
    for part in params:
        print('\t', end='')
        print(part)
